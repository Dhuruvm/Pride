# Priority:
- Creating the new embed parser
- Starting implementation of the bot
- Assigning Harry translation tasks
- Running the actual bot (getting it to start)