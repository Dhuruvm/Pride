# Source is being rewritten, however lemme go ahead and open source the project before you have a chance to sell off the code Adam.
