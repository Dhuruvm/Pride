from .alias import Alias

__all__ = ("Alias",)
