from .confess import Confess

__all__ = ("Confess",)