from .vanity import Vanity

__all__ = ("Vanity",)
