from .webhook import Webhook

__all__ = ("Webhook",)
